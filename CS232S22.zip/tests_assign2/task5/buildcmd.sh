#!/bin/bash
cmd="gcc -Wall -std=c11 array.c array_test.c -o array_test"
executable="array_test"
