#!/bin/bash
expected="build.sh intro.in intro.out"
