#!/bin/bash
expected="analyse.c"
