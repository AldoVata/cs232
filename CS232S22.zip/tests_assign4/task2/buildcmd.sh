#!/bin/bash
cmd="gcc -Wall -std=c11 analyse.c -o analyse"
executable="analyse"
