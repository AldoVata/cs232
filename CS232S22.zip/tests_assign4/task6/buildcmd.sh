#!/bin/bash
cmd="gcc -Wall -std=c11 construct_3_strs.c -o construct_3_strs"
executable="construct_3_strs"
