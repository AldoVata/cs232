#!/bin/bash
cmd="gcc -Wall -std=c11 construct_3.c -o construct_3"
executable="construct_3"
