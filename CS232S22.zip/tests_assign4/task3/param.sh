#!/bin/bash
expected="wordstats.c"
