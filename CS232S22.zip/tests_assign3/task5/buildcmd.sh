#!/bin/bash
cmd="gcc -Wall -std=c11 set_bits.c test_set_bits.c -o test_set_bits"
executable="test_set_bits"
