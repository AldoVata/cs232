#!/bin/bash
cmd="make snode_test"
executable="snode_test"
