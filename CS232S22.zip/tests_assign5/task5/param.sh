#!/bin/bash
expected="construct_3_structs_add.c Makefile snode.h"
