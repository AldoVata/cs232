#!/bin/bash
expected="construct_3_structs_delete.c Makefile snode.h"
